(function ($, window, document, undefined) {

	App.medium = (function () {

		var elements = {
		};

		var settings = {
			label : 'medium'
		};

		function init() {
			App.small.initMobileMenu();
			App.main.initCatalogRelatedMover();
			initHeaderSearch();
			App.main.reflowEqualizer('medium');
			// console.log('app.medium.init');
		}

		function destroy() {
			// console.log('app.medium.destory');
			App.small.destroyMobileMenu();
			destroyHeaderSearch();
		}

		function initHeaderSearch() {
			var $container  = $('#main-header .header-search'),
				$iContainer = $container.find('.header-search-field'),
				$input      = $iContainer.find('input'),
				$activator  = $container.find('a');

			$activator.on({
				'click.medium' : function(e) {
					e.preventDefault();

					if( $('#search-text').val() !== "" && $container.hasClass('active') ) {
						$('#search-form').submit();
					} else {
						$container.toggleClass('active');
						$input.focus();
					}
				}
			});

		}

		function destroyHeaderSearch() {
			$('#main-header .header-search-field')
				.removeClass('active')
				.siblings('a')
					.off('.medium');
		}

		// Reveal public methods
		return {
			init    : init,
			destroy : destroy,
			initHeaderSearch : initHeaderSearch,
			destroyHeaderSearch : destroyHeaderSearch,
		};
	}());

}(jQuery, this, this.document));
