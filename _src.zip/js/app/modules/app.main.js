(function ($, window, document, undefined) {

	App.main = (function () {

		var elements = {
			$win      : $(window),
			$doc      : $(document),
			$body     : $('body'),
			$nav      : $('#main-nav'),
		};

		var settings = {
			breakpointSmall    : 640,
			breakpointMedium   : 1024,
			breakpointLarge    : 1440,
			ieVer              : null
		};

		function init() {
			jQuery.ajaxSetup({ cache: false });

			initFoundation();
			initBrowserVer();
			// initOptionGroups();
			initMainSubNavClasses();
			initProductListViewer();
			initProductListGallery();
			initFeatureGallery();
			initContextNav();
			initDatePicker();
			initShipOnDatePicker();
			initDeliveryOnDatePicker();
			initDependentButtons();
			initAddressBookPanels();
			initInputValueCheck();
			initFormValidation();
			initIE8Fixes();
			// initCreditCardSelectType();
			initItemSortOrder();
			initItemsPerPage();
			initImagesLoaded();
			initProductReadMore();
			initProductShowReviews();
			initCheckVariationSelected();
			initSharre();
			initFresco();
			initToolTip();
			scrollTopOnInvalid();
			initGooglePlacesAutofill();
			checkoutSubmitValidation();
			initJsDisabledLinks();
			initJsLinkAnchorParent();
			initAddToWishlist();
			initSearchPaginationNav();
			// initContactButton();
			// console.log('app.main.init');
		}

		function initFoundation() {
			$(document).foundation({
			  equalizer: {
			    equalize_on_stack: true
			  },
			  accordion: {
			    // allow multiple accordion panels to be active at the same time
			    multi_expand: true,
			    toggleable: true
 			 }
			});
		}

		function initSearchPaginationNav() {
			$(".search-pagination .page").on("click", function() {
				var $page = $(this);
				var $pageContainer = $page.parents(".search-pagination");
				var merchantId = $pageContainer.data("merchant-id");
				var merchantSearchId = $pageContainer.data("merchant-search-id");
				var pageRangeBegin = $page.data("page-range-begin");
				var pageRangeEnd = $page.data("page-range-end");

				window.location.href = '/cgi-bin/UCSearch?MERCHANTID=' + merchantId + '&MERCHANTSEARCHID=' + merchantSearchId + '&RANGEBEGIN=' + pageRangeBegin + '&RANGEEND=' + pageRangeEnd;
			});
		}

		function initJsDisabledLinks() {
			$('.js-disabled-anchor').on('click', function disableLinks(event) {
				event.preventDefault();
			});
		}

		function initJsLinkAnchorParent() {
			$('.js-link-anchor-parent').on('click', function linkUpParent() {
				window.location.href = $(this).find('> a:first-child').attr('href');
			});
		}

		function initAddToWishlist() {
			$('#js-add-to-wishlist').on('click', function addToWishlist(event) {
				event.preventDefault();
				var data = {
					itemId: $('#wishlist-itemId').val(),
					priority: $('#wishlist-priority').val(),
					comments: $('#wishlist-comments').val()
				};

				$.ajax({
					url: '/rest/myaccount/wishlist',
				    type: 'post', // Notice
				    headers: {
				    	"cache-control": "no-cache" },
				    contentType: 'application/json; charset=UTF-8',
				    data: JSON.stringify(data),
				    dataType: 'json'
			  	}).done(function( result ) {

			  		$('#wishlist-modal').foundation('reveal', 'close');

			  		$('#wishlist-added-modal').foundation('reveal', 'open');

			  	});
			});
		}

		function reflowEqualizer(size) {

 			$("[data-equalizer-suspended]")
 				.find("[data-equalizer-watch-suspended]")
 				.attr('data-equalizer-watch', '')
 				.data('equalizer-watch', '')
 				.removeData('equalizer-watch-suspended')
 				.removeAttr('data-equalizer-watch-suspended');
			$("[data-equalizer-suspended]")
				.attr('data-equalizer', '')
				.data('equalizer', '')
				.removeData('equalizer-suspended')
				.removeAttr('data-equalizer-suspended');

			if (size == "large") {

				$(".equalizer-large-suspend[data-equalizer]")
					.find("[data-equalizer-watch]")
					.attr('data-equalizer-watch-suspended', '')
					.data('equalizer-watch-suspended', '')
					.removeData('equalizer-watch')
					.removeAttr('data-equalizer-watch')
					.css("height", "");

				$(".equalizer-large-suspend[data-equalizer]")
					.attr('data-equalizer-suspended', '')
					.data('equalizer-suspended', '')
					.removeData('equalizer')
					.removeAttr('equalizer');

			} else if (size == "medium") {

				$(".equalizer-medium-suspend[data-equalizer]")
					.find("[data-equalizer-watch]")
					.attr('data-equalizer-watch-suspended', '')
					.data('equalizer-watch-suspended', '')
					.removeData('equalizer-watch')
					.removeAttr('data-equalizer-watch')
					.css("height", "");
				$(".equalizer-medium-suspend[data-equalizer]")
					.attr('data-equalizer-suspended', '')
					.data('equalizer-suspended', '')
					.removeData('equalizer')
					.removeAttr('equalizer');

			} else {

				$(".equalizer-small-suspend[data-equalizer]")
					.find("[data-equalizer-watch]")
					.attr('data-equalizer-watch-suspended', '')
					.data('equalizer-watch-suspended', '')
					.removeData('equalizer-watch')
					.removeAttr('data-equalizer-watch')
					.css("height", "");
				$(".equalizer-small-suspend[data-equalizer]")
					.attr('data-equalizer-suspended', '')
					.data('equalizer-suspended', '')
					.removeData('equalizer')
					.removeAttr('equalizer');
			}

			$(document).foundation('equalizer', 'reflow');
		}

		function initGooglePlacesAutofill() {
			if( $('#shippingAddress1').length > 0 && $('#shippingAddress1').hasClass('js-google-autocomplete-field') ) {
				googlePlacesAutofill( 'shipping' );
			}

			if( $('#billingAddress1').length > 0 && $('#billingAddress1').hasClass('js-google-autocomplete-field') ) {
				googlePlacesAutofill( 'billing' );
			}

			if( $('#address1').length > 0 && $('#address1').hasClass('js-google-autocomplete-field') ) {
				googlePlacesAutofill( 'mpc' );
			}
		}

		function getGooglePlacesFormObj( form ) {
			var ids = {
				billing: {
					address1: "#billingAddress1",
					address2: "#billingAddress2",
					city: "#billingCity",
					state: "#ucBillingStateFieldId",
					zip: "#billingZip",
					country: "#ucFieldBillingCountry"
				},
				shipping: {
					address1: "#shippingAddress1",
					address2: "#shippingAddress2",
					city: "#shippingCity",
					state: "#ucShippingStateFieldId",
					zip: "#shippingZip",
					country: "#ucFieldShippingCountry"
				},
				mpc: {
					address1: "#address1",
					address2: "#address2",
					city: "#city",
					state: "#state",
					zip: "#zip",
					country: "#country"
				}
			};

			return ids[form];
		}

		//TODO: find out why it is rewriting the long address into address1 for shipping on the single-page checkout on blur
		function googlePlacesAutofill( form ) {

			if(!$.browser.webkit && typeof google !== 'undefined') {
				var options = {
					types: ['address']
				};
				var inputIdObj = getGooglePlacesFormObj( form );
				var input = $(inputIdObj.address1)[0];

				var autocomplete = new google.maps.places.Autocomplete(input, options);

				//prevent form from being submitted when someone selects an option with the enter key
				google.maps.event.addDomListener(input, 'keydown', function(event) {
					if (event.keyCode == 13) {
					    event.preventDefault();
					}
				});

				// When the user selects an address from the dropdown,
				// populate the address fields in the form.
				google.maps.event.addListener(autocomplete, 'place_changed', function() {
					var place = autocomplete.getPlace();

					// Variables for intermediate collection
					var streetNumber ="";
					var street = "";
					var postalCodeSuffix = "";
					// var neighborhood = "";

					// Final address variables
					var address1 = "";
					var city = "";
					var state = "";
					var postalCode = "";
					var country = "";

					for (var key in place.address_components) {
						var address_component = place.address_components[key];
						if (address_component.types[0] == "street_number") {
							streetNumber = address_component.short_name;
						}
						if (address_component.types[0] == "route") {
							street = address_component.long_name;
						}
						if (address_component.types[0] == "locality") {
							city = address_component.long_name;
						}
						// if (address_component.types[0] == "neighborhood") {
						//   neighborhood = address_component.long_name;
						// }
						if (address_component.types[0] == "administrative_area_level_1") {
							state = address_component.short_name;
						}
						if (address_component.types[0] == "postal_code") {
							postalCode = address_component.short_name;
						}
						if (address_component.types[0] == "postal_code_suffix") {
							postalCodeSuffix = address_component.short_name;
						}
						if (address_component.types[0] == "country") {
							country = address_component.long_name;
						}
					}

					address1 = (streetNumber + " " + street).trim();
					if (postalCodeSuffix) {
						postalCode += "-" + postalCodeSuffix;
					}
					// if (neighborhood) {
					//   city = neighborhood;
					// }

					// Perform some magic to set the searchable address field with only the address
					setTimeout(function(){
						$( inputIdObj.address1 ).val(address1)
							.on( "blur.checkout", function() {
								setTimeout(function(){
									$( inputIdObj.address1 ).val(address1);

									focusOnNextInput( inputIdObj.country );
								}, 0);

								$( inputIdObj.address1 ).off("blur.checkout");
							});
					}, 100);

				    $( inputIdObj.address2 ).val("");
				    $( inputIdObj.city ).val(city);
				    $( inputIdObj.state ).val(state);
				    $( inputIdObj.zip ).val(postalCode);
				    $( inputIdObj.country ).val(country);
				});
			}
		}

		function focusOnNextInput(el) {
			var $el = $( el );
			var $inputs = $el.closest('form').find(':input');
			var elIndex = $inputs.index($el[0]);
			if (elIndex >= 0 && elIndex + 1 < $inputs.size()) {
			  $inputs[elIndex + 1].focus();
			}
		}

		function focusOnFirstInput(el) {
			jQuery(el).find(':input').filter(":visible:first").focus();
		}

		function initBrowserVer() {
			settings.ieVer = ie();
		}

		function initOptionGroups() {
			var $optionGroups = $('.option-group');

			$optionGroups.each(function() {
				var $self = $(this);
				// this refers to option-group
				$self.find('li').each(function(){

					// this refers to option-group li
					$(this).on({
						'click' : function(){
							// stop if this class is already active
							if($(this).hasClass('active')){
								return;
							}

							// undo changes
							$self.find('li').removeClass('active');
							$self.find('input[type="radio"]').prop('checked', false);
							$self.find('input[type="text"]').stop(true, true).slideUp(300);

							// add changes to current
							$(this).addClass('active');
							$(this).find('input[type="radio"]').prop('checked', true);
							$(this).find('input[type="text"]').stop(true, true).slideDown(300).focus();
						}
					});
				});
			});
		}

		function initMainSubNavClasses() {
			$('#main-nav li:has(ul)').addClass('has-subnav');
		}

		function initProductListViewer() {
			var $viewers = $('.product-list-images.viewer');

			$viewers.each(function(i) {
				var $viewer = $(this),
					$list   = $viewer.find('ul'),
					$items  = $viewer.find('li'),
					itemsPerPage = 3,
					largeImageHolder = '',
					$largeImageHolder,
					viewerID     = 'product-viewer-'+ i;

				// Determine viewer ID
				if ($viewer.attr('id') === '' || $viewer.attr('id') === undefined) {
					$viewer.attr('id', viewerID);
				} else {
					viewerID = $viewer.attr('id');
				}

				// Create the large image holder HTML
				largeImageHolder =  '<div class="viewer-holder"><ul id="'+ viewerID +'-holder">';
				largeImageHolder += $list.html();
				largeImageHolder += '</ul></div>';

				// Create to jQuery object
				$largeImageHolder = $(largeImageHolder);

				// Swap out src for large version
				$largeImageHolder.find('img').each(function() {
					$(this).attr('src', $(this).data('large'));
				});

				// Append the HTML
				$viewer.prepend($largeImageHolder);

				// Add a class and ID to the list for more CSS specificy
				$list
					.wrap('<div class="viewer-list"></div>')
					.attr('id', viewerID +'-list');

				$viewer.find('a').on({
					'click' : function(e) {
						e.preventDefault();
					}
				});

				// Initialize carousel on large image holder
				$('#'+ viewerID +'-holder').slick({
					slidesToShow: 1,
					slidesToScroll: 1,
					arrows: false,
					fade: true,
					slide: 'li'
				});

				// Some IE detection.  IE doesn't give the LIs widths, this sets them
				if (settings.ieVer < 9) {
					$('#'+ viewerID +'-list li').each(function() {
						$(this).css('width', $(this).find('img').attr('width'));
					});
				}

				// Show the thumbnails if there's more than one image
				$('.product-list-images').imagesLoaded()
					.always(function imageLoaded(instance, image) {

						if ($items.length > itemsPerPage) {

								// Initialize carousel on thumbnails
								$('#'+ viewerID +'-list').slick({
									infinite: true,
									dots: true,
									slide: 'li',
									slidesToShow: itemsPerPage,
									slidesToScroll: itemsPerPage,
									asNavFor: '#'+ viewerID +'-holder',
									focusOnSelect: true,
									variableWidth: true,
									centerMode: true,
								});

							} else {
								$('#'+ viewerID +'-list').slick({
									infinite: false,
									dots: true,
									slide: 'li',
									slidesToShow: $list.length,
									slidesToScroll: itemsPerPage,
									asNavFor: '#'+ viewerID +'-holder',
									focusOnSelect: true,
									variableWidth: true,
									centerMode: true,
								});
								// Initialize carousel on thumbnails
							}
							$('.viewer .product-image').show();

							if ($(".viewer-list .slick-track li").size() <= 1) {
								$(".viewer-list").hide();
							}
					});
			});

		}

		function initProductListGallery() {
			var $galleries = $('.product-list-images.gallery ul');

			$galleries.each(function() {
				var $gallery = $(this),
					$list    = $gallery.find('ul'),
					$items   = $list.find('li');

				$gallery.slick({
					dots: true,
					slide: 'li',
					focusOnSelect: true,
					slidesToShow: 4,
					slidesToScroll: 4,
					responsive: [
						{
							breakpoint: settings.breakpointSmall,
							settings: {
								slidesToShow: 2,
								slidesToScroll: 2
							}
						}
					]
				});
			});
		}

		function initFeatureGallery() {
			var $galleryContainer = $('.featured-products-gallery');
			var $galleries = $galleryContainer.find('ul');
			var slideSpeed = typeof $galleryContainer.data('autoplay-speed') !== undefined ? parseInt($galleryContainer.data('autoplay-speed')) : 3000;
			var slideAutoplay = typeof $galleryContainer.data('autoplay') !== undefined ? $galleryContainer.data('autoplay') : true;

			$galleries.each(function() {
				var $gallery = $(this),
					$list    = $gallery.find('ul'),
					$items   = $list.find('li');

				$gallery.slick({
					dots: true,
					arrows: false,
					slide: 'li',
					focusOnSelect: true,
					slidesToShow: 1,
					slidesToScroll: 1,
					autoplay: slideAutoplay,
					autoplaySpeed: slideSpeed
				});
			});
		}

		function initContextNav() {
			var $navs = $('.context-nav');

			$navs.each(function() {
				var $nav    = $(this),
					$items  = $nav.find('> ul > li');

				$items.each(function() {
					var $item 	= $(this),
						$title	= $item.find('a'),
						$subnav = $item.find('ul');

					$title.on({
						'click' : function(e) {
							$item.toggleClass('active');

							e.preventDefault();
						}
					});
				});
			});
		}

		function initCatalogRelatedMover() {

			if (App.main.elements.$body.is('.catalog.sidebar') &&
				$('.sidebar-moved').length < 1) {

				var $sidebar = $('aside.sidebar'),
					$holder  = $('nav.context-nav').parent();

				$sidebar.clone().appendTo($holder).attr('class', 'sidebar-moved');
				$sidebar.hide();
			}
		}

		function initDependentButtons(){
			$('button, .button').each(function(){
				var $button = $(this),
					$dependents = $(this).data('depends');

				if($dependents){
					if (settings.ieVer < 9) {
						$button.removeAttr('disabled');
						/*jshint scripturl:true*/
						$button.attr('onclick', 'javascript:return false;');
					}


					$($dependents).each(function(){
						var $dependent = $(this);

						$dependent.on('keyup', function(){
							var value = $.trim($dependent.val());

							if (settings.ieVer < 9) {
								if (value.length > 0) {
									/*jshint scripturl:true*/
									$button.attr('onclick', 'javascript:return true;').removeClass('inactive');
								} else {
									/*jshint scripturl:true*/
									$button.attr('onclick', 'javascript:return false;').addClass('inactive');
								}
							} else {
								if (value.length > 0 ){
									$button.prop('disabled', false).removeClass('inactive');
								} else {
									$button.prop('disabled', true).addClass('inactive');
								}
							}
						});
					});
				}
			});
		}

		function initAddressBookPanels(){
			$('.shipping-panels').each(function(){

				var $panel = $(this),
					$addresses = $panel.find('.address');

				$addresses.each(function() {

					var $address   = $(this),
						prefix = $address.data('prefix'),
						form   = $($address.data('form'));

					$address.on('click', function() {
						$panel.find('.panel').removeClass('active');

						$address
							.find('.panel')
								.addClass('active')
								.end()
							.find('[data-field^="' + prefix + '"]').each(function(){
								var $input = $(this),
									name   = $input.data('field'),
									input  = form.find('[name="' + name + '"]'),
									value  = $input.text();


								input.val(value).parent('.label-move').removeClass('active');
							});
						$('.label-move input').trigger('change');
						$('html, body').animate({
					        scrollTop: $("#address-fields").offset().top - 50
					    }, 1000);
					});

				});
			});
		}

		function revertCatalogRelatedMover() {
			if (App.main.elements.$body.is('.catalog.sidebar') &&
				$('.sidebar-moved').length > 0) {

				$('.sidebar-moved').remove();
				$('aside.sidebar').show();
			}
		}

		function initFresco() {
			var imageArr = [];
			$( '.viewer-holder .product-image a' ).each(function createImageList() {
				imageArr.push({
					url: $(this).attr('href')
				});
			});
			$( '.viewer-holder .product-image a' ).click(function showFresco() {

				Fresco.show(imageArr, parseInt($(this).parent('li').attr('index')) + 1 );
			});
		}

		function initToolTip() {
			$('.has-tip').on('mouseenter mouseleave click', function addTheTip(event) {
				var $this = $(this);

				switch(event.type) {
					case 'mouseenter':
						$this.addClass('active');
						break;
					case 'mouseleave':
						$this.removeClass('active');
						break;
					default:
						$this.toggleClass('active');
						break;
				}

			});
		}

		function scrollTopOnInvalid() {
			$("input").unbind("invalid").bind("invalid", function(event) {
				var $this = $(this);
				if ( $this.offset().top - 75 < elements.$win.scrollTop() ) {
					elements.$win.scrollTop($this.offset().top - 75);
				}
			});
		}

		function initDatePicker() {
			$('input[type="date"]')
				.pickadate({
					weekdaysShort: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
					showMonthsShort: true,
					format: 'mm/dd/yyyy'
				})
				.parent('label')
					.addClass('calendar-picker');
		}

		function initShipOnDatePicker() {
			if( typeof shipOnDatePickadateMin !== "undefined" && typeof shipOnDatePickadateDisabled !== "undefined" ) {
				$('#shipOnDate')
					.pickadate({
						weekdaysShort: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
						showMonthsShort: true,
						format: 'mm/dd/yyyy',
						min: shipOnDatePickadateMin,
						disable: shipOnDatePickadateDisabled

					})
					.parent('label')
						.addClass('calendar-picker');
			}
		}

		function initDeliveryOnDatePicker() {
			if( typeof deliveryOnDatePickadateMin !== "undefined" && typeof deliveryOnDatePickadateDisabled !== "undefined" ) {
				$('#deliveryDate')
					.pickadate({
						weekdaysShort: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
						showMonthsShort: true,
						format: 'mm/dd/yyyy',
						min: deliveryOnDatePickadateMin,
						disable: deliveryOnDatePickadateDisabled

					})
					.parent('label')
						.addClass('calendar-picker');
			}
		}

		function initInputValueCheck() {
			// $('.label-move input[value!=""]').parent('.label-move').addClass('active');

			$('.label-move input').on('change', function() {
				var $this = $(this);

				if( $this.val() ) {
					$this.parent('.label-move').addClass('active');
				} else {
					$this.parent('.label-move').removeClass('active');
				}

			});
			$('.label-move input').trigger('change');
		}

		function initFormValidation(){
			setTimeout(function delayValidationForHandlebarsForms() { // this should be called when the handlebarsInit event is fired

				$('form.validate').each(function validateEachForm(){
					var $form = $(this),
						$inputs = $form.find('input, select, textarea'),
						$submit = $form.find('button[type="submit"], input[type="submit"], input[type="button"]');

					var isValid = $form.validate({
						messages: setValidationMessages($inputs),
						onkeyup: false
					});

					//do an intial check
					checkFullyValid( $form, isValid, $submit );

					$inputs.on('keyup blur', function checkOnKeyupBlur() {
						checkFullyValid( $form, isValid, $submit );
					} );
				});
			}, 1000);
		}

		function checkFullyValid( $form, isValid, $submit ) {
			if( $form.is(':visible') && isValid.checkForm() ) { //this visibility check is mostly for
				$submit.prop('disabled', false).removeClass('inactive');
			} else {
				$submit.prop('disabled', true).addClass('inactive');
			}
		}

		function setValidationMessages(selector){
			var messages = {};
			$(selector).each(function(){
				var data = $(this).data();
				if(data){
					messages[this.name] = data;
				}
			});

			return messages;
		}

		// function initCreditCardSelectType() {
		// 	$('#creditCardNumber').on('blur', function autofillCorrectType(){
		// 		var $cardTypeSelect = $('#creditCardType');

		// 		if( $cardTypeSelect.val() === "" || $cardTypeSelect.val() === null) {
		// 			var firstNumber = parseInt($(this).val().trim().charAt(0));
		// 			var cardType = '';

		// 			switch( firstNumber ) {
		// 				case 3:
		// 					cardType = "Amex";
		// 					break;
		// 				case 4:
		// 					//fixed the creditCardType autofill so that it works with the value as "Visa" or "VISA".
		// 					//this gets value of the option that has a text value of "Visa", since it's consistent across all vms
		// 					cardType = $cardTypeSelect.children('option').filter(function () { return $(this).html().trim() == "Visa"; }).val();
		// 					break;
		// 				case 5:
		// 					cardType = "MasterCard";
		// 					break;
		// 				case 6:
		// 					cardType = "Discover";
		// 					break;
		// 			}
		// 			$cardTypeSelect.val( cardType );
		// 		}
		// 	});
		// }

		function initItemSortOrder() {
			$("#itemSortOrder").on('change', function updateSortOrderParam() {
				window.location.href = updateQueryString('changeItemSortOrder', encodeURIComponent($(this).val()));
			});
		}

		function initItemsPerPage() {
			$("#itemsPerPage").on('change', function updatePerPageParam() {
				window.location.href = updateQueryString('changeItemsPerPage', encodeURIComponent($(this).val()));
			});
		}

		function initImagesLoaded() {
			$('.product-list-images').imagesLoaded()
				.fail(function imageLoadFailed() {
					console.error("One or more images failed to load.");
				});
		}

		function initProductReadMore() {
			$('#item-read-more').on('click', function clickReadMore() {
				$('#product-description-tab').trigger('click');
				$('html, body').animate({scrollTop: $('#panel-product-description').offset().top -100 }, 'slow');
			});
		}

		function initProductShowReviews() {
			$('#item-show-reviews').on('click', function clickShowReviews() {
				$('#product-reviews-tab').trigger('click');
				$('html, body').animate({scrollTop: $('#panel-product-reviews').offset().top -100 }, 'slow');
			});
		}

		function initCheckVariationSelected() {
			$('#add-cart-form').on('submit', function(event) {
				$('#add-cart-form small.error').remove();
				if($('.variationSelectBox').val() === "") {
					event.preventDefault();
					$('.variationSelectBox').each(function() {
						var $this = $(this);
						if($this.is(":visible")) {
							$this.after('<small class="error" style="'+$this.style+'">This is required.</small>');
						}
					});
				}
			});

			$('.variationSelectBox').on('change', function() {
				$('#add-cart-form small.error').remove();
			});
		}

		function initSharre() {
			$(".social-buttons .facebook").sharrre({
				share: {
					facebook: true
				},
				template: '	<a href="#" title="Like">' +
					'<span class="icon-facebook"></span>' +
					'Share' +
					'</a> ',
				enableHover: false,
				click: function(api, options) {
					api.simulateClick();
					api.openPopup('facebook');
				}
			});

			$(".social-buttons .twitter").sharrre({
				share: {
					twitter: true
				},
				template: '	<a href="#" title="Tweet">' +
					'<span class="icon-twitter"></span>' +
					'Tweet' +
					'</a> ',
				enableHover: false,
				click: function(api, options) {
					api.simulateClick();
					api.openPopup('twitter');
				}
			});

			$(".social-buttons .pinterest").sharrre({
				share: {
					pinterest: true
				},
				template: '	<a href="#" title="Pin">' +
					'<span class="icon-pinterest"></span>' +
					'Pin' +
					'</a> ',
				enableHover: false,
				buttons: {
					pinterest: {
				    	media: jQuery('.slick-active img').attr('src'),
				    	description: $(".social-buttons .pinterest").data('text')
					}
				},
				click: function(api, options) {
					api.simulateClick();
					api.openPopup('pinterest');
				}
			});
		}

		function ucReviewSubmitValidation() {
			// Tuck away the form we're dealing with
			var form = $(this);

			// Determine which button was clicked then remove the flag
			var clickedButton = $("input[type=submit][clicked=true],input[type=image][clicked=true],button[type=submit][clicked=true]", form);
			clickedButton.removeAttr("clicked");

			// If we've passed validation then return true so the form will submit normally, but clear the flag first in
			// case they back up and use the form a second time.
			if (form.attr("validationPassed") == "true") {
				form.removeAttr("validationPassed");
				return true;
			}

			// Perform any normal synchronous validation here.

			// Perform logic about what type of validation we need to perform.  For example if we've got a credit card then
			// we have to tokenize it before continuing.
			var performAsyncValidation = $('#creditCardNumber').size() !== 0;

			if (performAsyncValidation) {
				// Stop propagation of this event so the form doesn't submit.
				event.preventDefault();

				// Perform the presubmit operation with the checkoutTokenization object.  The callback function passed in
				// is always guaranteed to be called asynchronous (otherwise our re-clicks wouldnt work)
				var creditCardTokenRequest = {
					'firstName': $('#firstName').val(),
					'lastName': $('#lastName').val(),
					'address1': $('#address1').val(),
					'address2': $('#address2').val(),
					'city': $('#city').val(),
					'state': $('#state').val(),
					'zip': $('#zip').val(),
					'country': $('#country').val(),
					'creditCardNumber': $('#creditCardNumber').val(),
					'creditCardExpMonth': $('#creditCardExpMonth').val(),
					'creditCardExpYear': $('#creditCardExpYear').val(),
					'creditCardVerificationNumber': $('#creditCardVerificationNumber').val()
				};

				//remove any past errors if present
				$('.token-response-error').remove();

				checkoutTokenization.formPresubmit(creditCardTokenRequest, function(creditCardTokenResponse) {

					if (creditCardTokenResponse.success) {
						if (creditCardTokenResponse.maskedCard) {
							$('#creditCardNumber').val(creditCardTokenResponse.maskedCard);
						}

						if (creditCardTokenResponse.cardToken) {
							$('#creditCardToken').val(creditCardTokenResponse.cardToken);
						}

						// Set the flag that allows the submit to take place on the callback
						form.attr("validationPassed", "true");

						// Maintain which button they clicked originally for form submission integrity.
						if (clickedButton.size() > 0) {
							// Click the same button
							clickedButton.trigger("click");
						} else {
							// Call the native method to submit the form which will not call our onsubmit
							form.submit();
						}
					} else {
						var errors = '';
						var errorHtml = '';
						var $mpc = $('#ucReview');


						for (var i = 0; i < creditCardTokenResponse.errors.length; i++) {
							errors += creditCardTokenResponse.errors[i] + '<br>';
						}

						errorHtml += '<div class="row token-response-error">' +
										'<div class="columns small-full">' +
										'<div class="alert error text-left no-margin-top no-margin-bottom">' +
										errors +
										'</div></div></div>';

						//remove any past errors if present
						$('.token-response-error').remove();

						$mpc.prepend(errorHtml);
						$('html, body').animate({scrollTop: $mpc.offset().top -100 }, 'slow');

						console.log(creditCardTokenResponse.errors);
					}
				});

				return false;
			} else {
				// Allow the normal submit to take place
				return true;
			}
		}

		function ucSingleSubmitValidation(event) {
			// Tuck away the form we're dealing with
			var form = $(this);

			// Determine which button was clicked then remove the flag
			var clickedButton = $("input[type=submit][clicked=true],input[type=image][clicked=true],button[type=submit][clicked=true]", form);
			clickedButton.removeAttr("clicked");

			// If we've passed validation then return true so the form will submit normally, but clear the flag first in
			// case they back up and use the form a second time.
			if (form.attr("validationPassed") == "true") {
				form.removeAttr("validationPassed");
				return true;
			}

			// Perform logic about what type of validation we need to perform.  For example if we've got a credit card then
			// we have to tokenize it before continuing.
			var performAsyncValidation = $('#creditCardNumber').size() !== 0;

			if (performAsyncValidation) {
				// Stop propagation of this event so the form doesn't submit.
				event.preventDefault();

				// Perform the presubmit operation with the checkoutTokenization object.  The callback function passed in
				// is always guaranteed to be called asynchronous (otherwise our re-clicks wouldnt work)
				var creditCardTokenRequest = null;
				if($('#billingDifferent').is(':checked')) {
					//billing info is different from shipping
					creditCardTokenRequest = {
						firstName: $('#billingFirstName').val(),
						lastName: $('#ucidBillingLastName').val(),
						address1: $('#billingAddress1').val(),
						address2: $('#billingAddress2').val(),
						city: $('#billingCity').val(),
						state: $('#ucBillingStateFieldId').val(),
						zip: $('#billingZip').val(),
						country: $('#ucFieldBillingCountry').val(),
						creditCardNumber: $('#creditCardNumber').val(),
						creditCardExpMonth: $('#creditCardExpMonth').val(),
						creditCardExpYear: $('#creditCardExpYear').val(),
						creditCardVerificationNumber: $('#creditCardVerificationNumber').val()
					};
				} else {

					creditCardTokenRequest = {
						firstName: $('#shippingFirstName').val(),
						lastName: $('#shippingLastName').val(),
						address1: $('#shippingAddress1').val(),
						address2: $('#shippingAddress2').val(),
						city: $('#shippingCity').val(),
						state: $('#ucShippingStateFieldId').val(),
						zip: $('#shippingZip').val(),
						country: $('#ucFieldShippingCountry').val(),
						creditCardNumber: $('#creditCardNumber').val(),
						creditCardExpMonth: $('#creditCardExpMonth').val(),
						creditCardExpYear: $('#creditCardExpYear').val(),
						creditCardVerificationNumber: $('#creditCardVerificationNumber').val()
					};
				}

				checkoutTokenization.formPresubmit(creditCardTokenRequest, function(creditCardTokenResponse) {

					if (creditCardTokenResponse.success) {
						if (creditCardTokenResponse.maskedCard) {
							$('#creditCardNumber').val(creditCardTokenResponse.maskedCard);
						}

						if (creditCardTokenResponse.cardToken) {
							$('#creditCardToken').val(creditCardTokenResponse.cardToken);
						}

						// Set the flag that allows the submit to take place on the callback
						form.attr("validationPassed", "true");

						// Maintain which button they clicked originally for form submission integrity.
						if (clickedButton.size() > 0) {
							// Click the same button
							clickedButton.trigger("click");
						} else {
							// Call the native method to submit the form which will not call our onsubmit
							form.submit();
						}
					} else {
						var errors = '';
						var errorHtml = '';
						var $single = $('#ucSingle');

						for (var i = 0; i < creditCardTokenResponse.errors.length; i++) {
							errors += creditCardTokenResponse.errors[i] + '<br>';
						}

						errorHtml += '<div class="row token-response-error">' +
										'<div class="columns small-full">' +
										'<div class="alert error text-left no-margin-top no-margin-bottom">' +
										errors +
										'</div></div></div>';

						//remove any past errors if present
						$('.token-response-error').remove();

						$single.prepend(errorHtml);
						$('html, body').animate({scrollTop: $single.offset().top -100 }, 'slow');

						console.log(creditCardTokenResponse.errors);
					}
				});

				return false;
			} else {
				// Allow the normal submit to take place
				return true;
			}
		}

		function checkoutSubmitValidation() {
			// Track which button was clicked on all forms
		    $("form input[type=submit], form input[type=image], form button[type=submit]").click(function() {
		      $("input[type=submit], input[type=image], button[type=submit]", $(this).parents("form")).removeAttr("clicked");
		      $(this).attr("clicked", "true");
		    });

		    // Set required attributes on billing fields when shipping is different from billing is selected
		    var requiredBillingFields = $('#billingFirstName, #ucidBillingLastName, #billingAddress1, #billingCity, #ucBillingStateFieldId, #billingZip');
			$('#billingDifferent').on('change', function toggleRequiredOnChange() {
				if($(this).is(':checked') ) {
					requiredBillingFields.each(function(i, elem) {
						elem.required = true;
					});
				} else {
					requiredBillingFields.each(function(i, elem) {
						elem.required = false;
					});
				}
			});

			// register onSubmit validation for card tokenization
			// $('#ucReview').on('submit', ucReviewSubmitValidation);
			// $('#ucSingle').on('submit', ucSingleSubmitValidation);
		}

		function initIE8Fixes() {
			if (settings.ieVer < 9) {
				$('.product-list-images.small.three-up li:nth-child(3n+1)').addClass('fourth');
			}
		}

		function ie() {

			var undef,
				v = 3,
				div = document.createElement('div'),
				all = div.getElementsByTagName('i');

			while (
				div.innerHTML = '<!--[if gt IE ' + (++v) + ']><i></i><![endif]-->',
				all[0]
			);

			return v > 4 ? v : undef;
		}

		function updateQueryString(key, value, url) {
			if (!url) url = window.location.href;

			var re = new RegExp("([?&])" + key + "=.*?(&|#|$)(.*)", "gi"),
			hash = url.split('#');

			if (re.test(url)) {
				if (typeof value !== 'undefined' && value !== null)
					return url.replace(re, '$1' + key + "=" + value + '$2$3');
				else {
					url = hash[0].replace(re, '$1$3').replace(/(&|\?)$/, '');
					if (typeof hash[1] !== 'undefined' && hash[1] !== null)
						url += '#' + hash[1];
					return url;
				}
			} else {
				if (typeof value !== 'undefined' && value !== null) {
					var separator = url.indexOf('?') !== -1 ? '&' : '?';
					url = hash[0] + separator + key + '=' + value;
					if (typeof hash[1] !== 'undefined' && hash[1] !== null)
						url += '#' + hash[1];
					return url;
				} else
					return url;
			}
		}

		// Reveal public methods and global elements, settings
		return {
			elements : elements,
			settings : settings,
			init    : init,
			initCatalogRelatedMover : initCatalogRelatedMover,
			revertCatalogRelatedMover : revertCatalogRelatedMover,
			reflowEqualizer: reflowEqualizer
		};
	}());

}(jQuery, this, this.document));