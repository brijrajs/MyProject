(function ($, window, document, undefined) {

	App.small = (function () {

		var elements = {
		};

		var settings = {
		};

		function init() {
			// console.log('app.small.init');
			initInputLabels();
			initMobileMenu();
			App.main.revertCatalogRelatedMover();
			initAddressBookPanels();
			initHeaderSearch();
			App.main.reflowEqualizer('small');
		}

		function destroy() {
			// console.log('app.small.destory');
			destroyInputLabels();
			destroyMobileMenu();
			destroyAddressBookPanels();
			destroyHeaderSearch();
		}

		function initAddressBookPanels(){
			$('.shipping-panels .address').each(function(){

				$(this).on('click.small', function(){
					var prefix = $(this).data('prefix'),
						form = $($(this).data('form'));

					$(this).find('[data-field^="' + prefix + '"]').each(function(){
						var name = $(this).data('field'),
							input = form.find('[name="' + name + '"]'),
							value = $(this).text();

						if(value.length > 0 && !input.is('select')){
							input.parent().addClass('active');
						} else {
							input.parent().removeClass('active');
						}
					});
				});
			});
		}

		function destroyAddressBookPanels(){
			$('.shipping-panels .address').each(function(){
				$(this).off('click.small');
			});
		}

		function initInputLabels() {
			var $inputs = $('.label-move');

			$inputs.each(function() {
				var $self  = $(this),
					$input = $self.find('input, textarea'),
					$select = $self.find('select'),
					$label = $self.find('> span');

				if($select.length > 0){
					$label.css('display', 'none');
				}

				if($input.length > 0){
					$input
						.data('placeholder', $input.attr('placeholder'))
						.attr('placeholder', '')
						.on({
							'focus.small' : function() {
								$self.addClass('active');
							},
							'blur.small' : function() {
								if ($input.val() === '') {
									$self.removeClass('active');
								}
							}
						});
				}
				$('.label-move input').trigger('change');
			});
		}

		function destroyInputLabels() {
			var $inputs = $('.label-move');

			$inputs.each(function() {
				var $self  = $(this),
					$input = $self.find('input, textarea'),
					$select = $self.find('select'),
					$label = $self.find('> span');

				if($select.length > 0){
					$label.css('display', '');
				}

				$input
					.attr('placeholder', $input.data('placeholder'))
					.off('.small');

				$self.removeClass('active');

			});
		}

		function initMobileMenu() {
			$('#main-header .js-skip-nav').on({
				'click.small' : function(e) {
					if( !App.main.elements.$body.hasClass('main-menu-active') ) {
						App.main.elements.$body.addClass('main-menu-active');
						$("html").swipe( {
							//Generic swipe handler for all directions
							swipe:function(event, direction, distance, duration, fingerCount, fingerData) {
								if(direction == "left") {
									App.main.elements.$body.removeClass('main-menu-active');
								}
							},
							fallbackToMouseEvents: false,
							allowPageScroll: "vertical",
							excludedElements: ".noSwipe"
							//Default is 75px, set to 0 for demo so any distance triggers swipe
							// threshold: 0
						});

					} else {
						App.main.elements.$body.removeClass('main-menu-active');
						$("html").swipe("destroy");
					}
					e.preventDefault();
				}
			});
		}

		function destroyMobileMenu() {
			App.main.elements.$body.removeClass('main-menu-active');
			$("html").swipe("destroy");
			$('#main-header .js-skip-nav').off('click.small');

			$('#main-header .icon-menu').off('.small');
		}

		function initHeaderSearch() {
			var $container  = $('#main-header .header-search'),
				$iContainer = $container.find('.header-search-field'),
				$input      = $iContainer.find('input'),
				$activator  = $container.find('a');

			$activator.on({
				'click.small' : function(e) {
					e.preventDefault();

					if( $('#search-text').val() !== "" ) {
						$('#search-form').submit();
					} else {
						$input.focus();
					}
				}
			});

			// Below is mainly just an IE11 fix.  IE11 was failing to focus the input on click.
			$input.on({
				'click.small' : function(e) {
					e.preventDefault();
					$input.focus();
				}
			});

		}

		function destroyHeaderSearch() {
			var $container  = $('#main-header .header-search'),
				$iContainer = $container.find('.header-search-field'),
				$input      = $iContainer.find('input'),
				$activator  = $container.find('a');

			$activator.off('.small');
			$input.off('.small');
		}

		// Reveal public methods
		return {
			init    : init,
			destroy : destroy,
			initMobileMenu : initMobileMenu,
			destroyMobileMenu : destroyMobileMenu
		};
	}());

}(jQuery, this, this.document));