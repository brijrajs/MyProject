(function ($, window, document, undefined) {

	App.large = (function () {

		var elements = {
			subNavTimeout : false
		};

		var settings = {
			subNavTimer : 500
		};

		function init() {
			App.medium.initHeaderSearch();
			App.main.initCatalogRelatedMover();
			initHeaderSubNavAction();
			initFixedMenu();
			App.main.reflowEqualizer('large');
			// console.log('app.large.init');
		}

		function destroy() {
			// console.log('app.large.destroy');
			App.medium.destroyHeaderSearch();
			destroyHeaderSubNavAction();
			destroyFixedMenu();
		}

		function initHeaderSubNavAction() {

			var $linksNew = $("#main-nav li");

			$linksNew.on('mouseenter.large', function(){
               $(this).addClass('active');
               if (this.deactivateTimer) {
                 clearTimeout(this.deactivateTimer);
                 this.deactivateTimer = null;
               }
			});
			$linksNew.on('mouseleave.large', function(){

               var $that = $(this);
               this.deactivateTimer = setTimeout(function(){
               	 $that.removeClass('active');
               }, settings.subNavTimer);

			});

			$('html').on({
				'click.headerSubNav' : function() {
					$('#main-nav .active').removeClass('active');
				}
			});
		}

		function destroyHeaderSubNavAction() {
			$('html').off('.headerSubNav');
			$("#main-nav li:has(ul) > a").off('.large');
			$("#main-nav li:has(ul) > a").siblings().off('.large');
		}

		function initFixedMenu() {
			var startPos = $('.secondary-masthead').height();

			$(App.main.elements.$win).on({
				'scroll.large' : function() {
					if ($(this).scrollTop() > startPos + 20) {
						App.main.elements.$body.addClass('fix-nav');
					} else {
						App.main.elements.$body.removeClass('fix-nav');
					}

					if ($(this).scrollTop() > (startPos + 37)) {
						App.main.elements.$body.addClass('fix-nav-deux');
					} else {
						App.main.elements.$body.removeClass('fix-nav-deux');
					}
				}
			});
		}

		function destroyFixedMenu() {
			$(App.main.elements.$win).off('.large').removeClass('fix-nav fix-nav-deux');
		}


		// Reveal public methods
		return {
			init    : init,
			destroy : destroy,
		};
	}());

}(jQuery, this, this.document));